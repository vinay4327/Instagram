import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:instagram_clone/resources/repository.dart';
import 'package:instagram_clone/ui/insta_home_screen.dart';
import 'package:instagram_clone/ui/login_screen.dart';



void main() => runApp(MyApp());

class Myapp extends StatefulWidget {
  @override
   MyappState createState() {
    return new MyappState();
}
}

class MyappState extends State<Myapp> {
  var _repository= Repository();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Instagram',
      debugShowCheckedModeBanner: false,
      theme: new ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: Colors.black,
        primaryIconTheme: IconThemeData(color:Colors.black),
        primaryTextTheme: TextTheme(title: TextStyle(color:Colors.black,fontFamily:"Aveny")),
        textTheme: TextTheme(title:TextStyle(color:Colors.black))),
      home: FutureBuilder(
        future: _repository.getCurrentuser()),
        builder: (context, AsyncSnapshot<FirebaseUser>snapshot){
          if (snapshot.hasData) {
            return InstaHomeScreen();
           }
         },
    ));

  }

}

